#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQuickView>

#include <QtGui>

int main(int argc, char *argv[])
{
//    QGuiApplication app(argc, argv);

//    QQmlApplicationEngine engine;
//    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));

    QGuiApplication app(argc, argv);
    QQuickView view;

    QDirModel model;
    view.rootContext()->setContextProperty("dirModel", &model);

    view.setSource(QUrl::fromLocalFile("view.qml"));
    view.show();

    return app.exec();
}
